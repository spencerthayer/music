# @strudel/xen

This package adds xenharmonic / microtonal functions to strudel Patterns. Further documentation + examples will follow.

## Install

```sh
npm i @strudel/xen --save
```
