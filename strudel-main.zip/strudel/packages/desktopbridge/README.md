# @strudel/desktopbridge

This package contains utilities used to communicate with the Tauri backend