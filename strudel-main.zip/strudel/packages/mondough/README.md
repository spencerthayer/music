# @strudel/mondough

connects mondo to strudel.
