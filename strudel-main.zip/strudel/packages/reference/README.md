# @strudel/reference

this package contains metadata for all documented strudel functions, useful to implement a reference.

```js
import { reference } from '@strudel/reference';
console.log(reference)
```
