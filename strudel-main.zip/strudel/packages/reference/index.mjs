import jsdoc from '../../doc.json';
export const reference = jsdoc;
