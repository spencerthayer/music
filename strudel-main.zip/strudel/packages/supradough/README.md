# supradough

platform agnostic synth and sampler intended for live coding. a reimplementation of superdough.