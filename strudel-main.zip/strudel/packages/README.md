# Packages

Each folder represents one of the @strudel/* packages [published to npm](https://www.npmjs.com/org/strudel).

To understand how those pieces connect, refer to the [Technical Manual](https://codeberg.org/uzu/strudel/wiki/Technical-Manual) or the individual READMEs.
