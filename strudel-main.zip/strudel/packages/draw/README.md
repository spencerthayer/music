# @strudel/canvas

Helpers for drawing with the Canvas API and Strudel

## Install

```sh
npm i @strudel/canvas --save
```
