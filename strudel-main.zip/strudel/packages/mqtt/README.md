# @strudel/serial

This package adds webserial functionality to strudel Patterns, for e.g. sending messages to arduino microcontrollers.
