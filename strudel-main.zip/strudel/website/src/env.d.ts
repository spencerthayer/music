/// <reference path="../.astro/types.d.ts" />
/// <reference types="astro/client" />

declare module 'date-fns';
