import LiteYouTubeEmbed from 'react-lite-youtube-embed';
import 'react-lite-youtube-embed/dist/LiteYouTubeEmbed.css';

export function Youtube(props) {
  return <LiteYouTubeEmbed {...props} />;
}
