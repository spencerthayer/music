# samples folder

1. copy any samples to this folder
2. run `npx @strudel/sampler` from this folder
3. add `samples('local:')` to your code
