# paper

## iclc2023

from the strudel project root:

```sh
npm run iclc
npm run iclc-nocite # try this if you get an error
```

## old

Work in progress on a paper about strudel

To build you will need

- pandoc
  - pandoc-url2cite (`npm install -g pandoc-url2cite`)
- latex/xelatex
- python
  - pandocfilters (`pip3 install pandocfilters`)
