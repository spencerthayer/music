# buildless examples

These examples show you how strudel can be used in a regular html file, without the need for a build tool.

Most examples are using [skypack](https://www.skypack.dev/)
