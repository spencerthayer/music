# @strudel/tidal

This is an experiment in implementing tree-sitter for parsing haskell.

```sh
pnpm i
cd haskell
pnpm copy-wasm
pnpm dev
```
