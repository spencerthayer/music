# minimal repl

This folder demonstrates how to set up a minimal strudel repl using vite and vanilla JS. Run it using:

```sh
npm i
npm run dev
```

If you're looking for a more feature rich alternative, have a look at the [../codemirror-repl](codemirror-repl example)
