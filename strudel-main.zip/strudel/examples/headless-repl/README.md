# headless-repl demo

This demo shows how to use strudel in "headless mode".
Buttons A / B / C will switch between different patterns.
It showcases the usage of the `@strudel/web` package, using [vite](https://vitejs.dev/) as the dev server.

## Running

```sh
pnpm i && cd examples/headless-repl
pnpm dev
# open http://localhost:5173/
```
