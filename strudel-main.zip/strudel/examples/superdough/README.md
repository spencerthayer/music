# superdough demo

This demo shows how to use [superdough](https://www.npmjs.com/package/superdough) with [vite](https://vitejs.dev/).

## Running

```sh
pnpm i && cd examples/headless-repl
pnpm dev
# open http://localhost:5173/
```
