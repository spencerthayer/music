# codemirror-repl example

This folder demonstrates how to set up a full strudel repl with the `@strudel/codemirror` package. Run it using:

```sh
pnpm i
pnpm dev
```
